<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.style3 {color: #FF9933}
</style>
</head>

<body>
<p><a href="#" class="style3">Pustaka SMK Negeri 2 Surabaya.com</a>
</p>
<h3>Buku adalah alat pengantar pada pengetahuan yang nantinya pengetahuan itu akan menuju pada kesuksesan </h3>
<div class="img"><img src="images/finance.jpg" alt="Finance" /></div>
Pustaka Smekda adalah sebuah perpustakaan yang telah berdiri sejak jaman belanda dan hingga kini perpustakaan itu masih tetap setia menemani siswa/i SMK Negeri 2 Surabaya Dahulu (STM 1) untuk memberikan pengetahuan yang beranekaragam  mulai dari pengetahuan tekhnik sampai dengan ilmu pelajaran umum tersedia disana.Harapannya dari sebuah perpustakaan kecil ini dapat membantu untuk  mencerdaskan &amp; menambah wawasan siswa/i SMK Negeri 2 Surabaya / Anggota Perpustakaan yang gemar membaca dan tergabung dalam Perpus Smekda Club untuk terus menjadi penjelajah dunia, sehingga Perpus Smkeda dapat memberikan wadah agar tetap terpenuhi kebutuhannya .
<p><a href="#" class="style3">Aktivitas Siswa Dalam Perpus </a></p>
<h3>Canda tawa pelajar Smekda </h3>
<div class="img"><img src="images/laptop1.jpg" alt="laptop" /></div>
<p>Dapat dilihat bahwa keantusiasan siswa/i SMK Negeri 2 dalam membaca sungguh luar biasa apa lagi didukung dengan tersedianya buku - buku yang memadai mulai dari buku tekhnik maupun pelajaran umum tersedia disini ,sehingga memudahkan para siswa/i untuk mengapresiasikan rasa keingintahuan para siswa/i dan sistem management perpustakaan SMK Negeri 2 yang baik sehingga sang siswa tidak cepat bosan dalam membaca dan diharapkan aktivitas siswa/i pada gambar disamping ini akan terus terbudaya sehingga dapat mencetak generasi STM yang mempunyai kualitas dan potensi yang handal dalam dunia kerja yang sangat luas meskipun hanya seorang lulusan STM yang dianggap remeh oleh orang - orang apriori. </p>
<p>&nbsp;</p>
</body>
</html>