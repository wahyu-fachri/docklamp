<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="0">
	<tr>
		<td><p><a href="#" class="style3">Profil Pustaka Smekda Surabaya </a>&nbsp;
<p><img src="images/laptop1.jpg" width="141" height="94" align="left" />	Pustaka Semekda telah berdiri sejak zaman belanda menjajah indonesia ,saat itu smkeda dijadikan tempat penyimpanan bala tentara kemudian oleh belanda dikembangkan menjadi sekolah tekhnik yang hanya boleh bersekolah adalah anak dari para pejabat pada saat itu dari sekolah belanda itu dikembangkan dan membentuk badan perpustakaan sekolah sampai saat ini perpustakaan itu masih tetap ada dan banyak sekali digemari oleh pelajar oleh para pelajar Smekda dan harapannya siswa lulusan Smekda dapat berkompetisi di dunia pekerjaan dengan berbekan ilmu pengetahuan yang telah mereka peroleh dari sekolah asalnya sehingga para pelajar Smekda dapat memunculkan generasi  generasi yang mampu menharumkan nama sekolah , negara, maupun agama dari tiap pelajar tersebut sehingga dengan latarbelakang seperti itu disini kami pihak pengelolah perpustakaan ingin mengelolah perpusnyakaannya sampai akhirnya saat ini kami menggunakan basis intranet untuk persewaan buku dari perpus Smekda</p>
<p></p>&nbsp;</td>
	</tr>
</table>

</body>
</html>