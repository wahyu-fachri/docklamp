<!--Author : adi-->
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form method="POST" action="exelogin.php" target="_top" style="font-family:arial;color:black;font-size:12px;">
	<table>
		<tr>
			<td>User</td>
			<td>:</td>
			<td><input type="text" name="user" /></td>
		</tr>
		<tr>
			<td>password</td>
			<td>:</td>
			<td><input type="password" name="pass" /></td>
		<tr>
			<td colspan="3" align="center"><input type="submit" name="Submit" value="Login" /></td>
		</tr>
		
	</table>
    </form>
</body>
</html>
