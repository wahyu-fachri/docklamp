<html>
<head><title>ERROR</title></head>
<body>
<?
	echo "You're Not Admin !";
?>
</body>
</html>
