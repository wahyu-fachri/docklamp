<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
  <table width="152" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="53">Search : </td>
      <td width="99">&nbsp;</td>
    </tr>
    <tr> <form method="post" action="searching.php">
      <td colspan="2"><input name="keyword" type="text" id="keyword" /></td>
    </tr>
    <tr>
      <td colspan="2">
        <label></label>
        <div align="center">
          <input type="submit" name="Submit" value="enter" />
        </div>
            </td>
    </tr></form>
  </table>
      <label></label>
  </form>
</div>
</body>
</html>
